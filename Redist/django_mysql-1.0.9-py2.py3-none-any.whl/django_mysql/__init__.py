# -*- coding: utf-8 -*-

__author__ = 'Adam Johnson'
__email__ = 'me@adamj.eu'
__version__ = '1.0.9'


default_app_config = 'django_mysql.apps.MySQLConfig'
